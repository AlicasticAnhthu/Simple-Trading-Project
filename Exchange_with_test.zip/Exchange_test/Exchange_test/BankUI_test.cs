﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Exchange
{
    [TestClass]
    public class BankUI_test
    {
        [TestMethod]
        public void TestRegister()
        {
            //Similar to bankM.AddBank()
            BankManager bankM = new BankManager();
            ShareManager shareM = new ShareManager();
            RecordManager recordM = new RecordManager();
            BankUI bkUI = new BankUI(bankM, shareM, recordM);
            bkUI.Register("A", "BankUI_BanksUnitTest.txt");
            //Reset bankID and DB
            bankM.resetIDtoAssign();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            //Assert
            Assert.AreEqual("A", bankM.GetAllBanks()[0].getName());
            Assert.AreEqual(0, bankM.GetAllBanks()[0].getMoneyOwed());
        }

        // If the bank is not found, a KeyNotFound exception is thrown and the program stops immediately.
        //The exception is in the scope of bankM => Can't assert here
        //Only consider the case that bank is registered

        [TestMethod]
        public void TestRequestAQuote1()
        {
            //Case 1: Unkown sharecode
            BankManager bankM1 = new BankManager();
            ShareManager shareM1 = new ShareManager();
            RecordManager recordM1 = new RecordManager();
            BankUI bkUI1 = new BankUI(bankM1, shareM1, recordM1);
            //Sample data
            bankM1.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM1.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM1.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM1.AddShare(new Share("VIC", 14.45), "BankUI_SharesUnitTest.txt");
            shareM1.AddShare(new Share("VIC", 14.45), "BankUI_SharesUnitTest.txt");
            shareM1.AddShare(new Share("VIC", 15.00), "BankUI_SharesUnitTest.txt");
            shareM1.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM1.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM1.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI1.RequestAQuote(0, "ABC", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM1.GetAllRequest();
            //Reset bankID, recordID and DB
            bankM1.resetIDtoAssign();
            recordM1.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(1, responses.Count);
            Assert.AreEqual(2, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("quote", responses[0].getTypeOfResponse());
            Assert.AreEqual(1, responses[0].getId());
            Assert.AreEqual("Unknown share code", responses[0].getShare().getCode());
        }

        [TestMethod]
        public void TestRequestAQuote2()
        {
            //Case 2: No shares with matching codes available
            BankManager bankM2 = new BankManager();
            ShareManager shareM2 = new ShareManager();
            RecordManager recordM2 = new RecordManager();
            BankUI bkUI2 = new BankUI(bankM2, shareM2, recordM2);
            //Sample data
            bankM2.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM2.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM2.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM2.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM2.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM2.AddShare(new Share("VIC", 15.00, false), "BankUI_SharesUnitTest.txt");
            shareM2.AddShare(new Share("VIC", 15.30, false), "BankUI_SharesUnitTest.txt");
            shareM2.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM2.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI2.RequestAQuote(0, "VIC", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM2.GetAllRequest();
            //Reset bankID, recordID and DB
            bankM2.resetIDtoAssign();
            recordM2.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(1, responses.Count);
            Assert.AreEqual(2, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("quote", responses[0].getTypeOfResponse());
            Assert.AreEqual(-1, responses[0].getShare().getPrice());
            Assert.AreEqual("VIC", responses[0].getShare().getCode());

        }

        [TestMethod]
        public void TestRequestAQuote3()
        {
            //Case 3: Successful request
            BankManager bankM3 = new BankManager();
            ShareManager shareM3 = new ShareManager();
            RecordManager recordM3 = new RecordManager();
            BankUI bkUI3 = new BankUI(bankM3, shareM3, recordM3);
            //Sample data
            bankM3.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM3.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM3.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM3.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM3.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM3.AddShare(new Share("VIC", 15.00), "BankUI_SharesUnitTest.txt");
            shareM3.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM3.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM3.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI3.RequestAQuote(0, "VIC", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM3.GetAllRequest();
            //Reset bankID, recordID and DB
            bankM3.resetIDtoAssign();
            recordM3.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(1, responses.Count);
            Assert.AreEqual(2, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("quote", responses[0].getTypeOfResponse());
            Assert.AreEqual(15.00, responses[0].getShare().getPrice());
            Assert.AreEqual(1, responses[0].getVolume());
        }

        [TestMethod]
        public void TestBuyShares1()
        {
            //Case 1: Unkown share code
            BankManager bankM4 = new BankManager();
            ShareManager shareM4 = new ShareManager();
            RecordManager recordM4 = new RecordManager();
            BankUI bkUI4 = new BankUI(bankM4, shareM4, recordM4);
            //Sample data
            bankM4.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM4.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("FLC", 13.45), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 14.45), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 15.00), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI4.BuyShares(0, "VNMMM", 1, 1,
                "BankUI_BanksUnitTest.txt", "BankUI_SharesUnitTest.txt", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM4.GetAllRequest();
            //Reset bankID, recordID and DB
            bankM4.resetIDtoAssign();
            recordM4.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(1, responses.Count);
            Assert.AreEqual(2, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("quote", responses[0].getTypeOfResponse());
            Assert.AreEqual(1, responses[0].getId());
            Assert.AreEqual("Unknown share code", responses[0].getShare().getCode());
        }

        [TestMethod]
        public void TestBuyShares2()
        {
            //Case 2: No shares with matching code is available
            BankManager bankM5 = new BankManager();
            ShareManager shareM5 = new ShareManager();
            RecordManager recordM5 = new RecordManager();
            BankUI bkUI5 = new BankUI(bankM5, shareM5, recordM5);
            //Sample data
            bankM5.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM5.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM5.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM5.AddShare(new Share("VIC", 14.45), "BankUI_SharesUnitTest.txt");
            shareM5.AddShare(new Share("VIC", 14.45), "BankUI_SharesUnitTest.txt");
            shareM5.AddShare(new Share("VIC", 15.00), "BankUI_SharesUnitTest.txt");
            shareM5.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM5.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM5.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI5.BuyShares(0, "FLC", 1, 1,
                "BankUI_BanksUnitTest.txt", "BankUI_SharesUnitTest.txt", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM5.GetAllRequest();
            //Reset bankID, recordID and DB
            bankM5.resetIDtoAssign();
            recordM5.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(1, responses.Count);
            Assert.AreEqual(2, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("quote", responses[0].getTypeOfResponse());
            Assert.AreEqual(-1, responses[0].getShare().getPrice());
            Assert.AreEqual("FLC", responses[0].getShare().getCode());
        }

        [TestMethod]
        public void TestBuyShares3()
        {
            //Case 3: Request volume <= Available volume (Successful transaction)
            BankManager bankM6 = new BankManager();
            ShareManager shareM6 = new ShareManager();
            RecordManager recordM6 = new RecordManager();
            BankUI bkUI6 = new BankUI(bankM6, shareM6, recordM6);
            RegulatorUI reUI6 = new RegulatorUI(bankM6, shareM6, recordM6);
            //Sample data
            bankM6.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM6.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM6.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM6.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM6.AddShare(new Share("VIC", 14.45), "BankUI_SharesUnitTest.txt");
            shareM6.AddShare(new Share("VIC", 15.00), "BankUI_SharesUnitTest.txt");
            shareM6.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM6.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM6.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI6.BuyShares(0, "VIC", 2, 15.15,
                "BankUI_BanksUnitTest.txt", "BankUI_SharesUnitTest.txt", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM6.GetAllRequest();
            Dictionary<System.Tuple<string, double>, System.Tuple<int, int>> share_dict =
                reUI6.GetInventoryReport();
            //Reset bankID, recordID and DB
            bankM6.resetIDtoAssign();
            recordM6.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(1, responses.Count);
            Assert.AreEqual(2, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("bought", responses[0].getTypeOfResponse());
            Assert.AreEqual(2, responses[0].getVolume());
            Assert.AreEqual(15.15, responses[0].getShare().getPrice());
            Assert.AreEqual("VIC", responses[0].getShare().getCode());
            Assert.AreEqual(new System.Tuple<int, int>(2, 2), share_dict[new System.Tuple<string, double>("VIC", 14.45)]);
            Assert.AreEqual(new System.Tuple<int, int>(1, 1), share_dict[new System.Tuple<string, double>("VIC", 15.00)]);
            Assert.AreEqual(30.30, bankM6.GetAllBanks()[0].moneyOwed);
        }

        [TestMethod]
        public void TestBuyShares4()
        {
            //Case 4: Request volume > Available volume && Request price <= Max available price
            BankManager bankM7 = new BankManager();
            ShareManager shareM7 = new ShareManager();
            RecordManager recordM7 = new RecordManager();
            BankUI bkUI7 = new BankUI(bankM7, shareM7, recordM7);
            //Sample data
            bankM7.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM7.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 14.45), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 15.00), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM7.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI7.BuyShares(0, "VIC", 3, 15.15,
                "BankUI_BanksUnitTest.txt", "BankUI_SharesUnitTest.txt", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM7.GetAllRequest();
            //Reset bankID, recordID and DB
            bankM7.resetIDtoAssign();
            recordM7.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(2, responses.Count);
            Assert.AreEqual(3, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("only", responses[0].getTypeOfResponse());
            Assert.AreEqual("quote", responses[1].getTypeOfResponse());
            Assert.AreEqual(2, responses[0].getVolume());
            Assert.AreEqual(2, responses[1].getVolume());
            Assert.AreEqual(15.15, responses[0].getShare().getPrice());
            Assert.AreEqual(15.30, responses[1].getShare().getPrice());
            Assert.AreEqual("VIC", responses[0].getShare().getCode());
        }

        [TestMethod]
        public void TestBuyShares5()
        {
            //Case 4: Request volume > Available volume && Request price > Max available price
            BankManager bankM4 = new BankManager();
            ShareManager shareM4 = new ShareManager();
            RecordManager recordM4 = new RecordManager();
            BankUI bkUI4 = new BankUI(bankM4, shareM4, recordM4);
            //Sample data
            bankM4.AddBank("A", "BankUI_BanksUnitTest.txt");
            shareM4.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("FLC", 13.45, false), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 14.45, false), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 15.00, false), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 15.30), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VNM", 15.30), "BankUI_SharesUnitTest.txt");
            shareM4.AddShare(new Share("VNM", 15.56), "BankUI_SharesUnitTest.txt");
            List<Response> responses = bkUI4.BuyShares(0, "VIC", 3, 15.35,
                "BankUI_BanksUnitTest.txt", "BankUI_SharesUnitTest.txt", "BankUI_RecordsUnitTest.txt");
            string[] lines = File.ReadAllLines("BankUI_RecordsUnitTest.txt");
            List<Request> requests = recordM4.GetAllRequest();
            //Reset bankID, recordID and DB
            bankM4.resetIDtoAssign();
            recordM4.resetRecordID();
            File.WriteAllText("BankUI_BanksUnitTest.txt", "");
            File.WriteAllText("BankUI_SharesUnitTest.txt", "");
            File.WriteAllText("BankUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(2, responses.Count);
            Assert.AreEqual(3, lines.Length);
            Assert.AreEqual(1, requests.Count);
            Assert.AreEqual("only", responses[0].getTypeOfResponse());
            Assert.AreEqual("quote", responses[1].getTypeOfResponse());
            Assert.AreEqual(2, responses[0].getVolume());
            Assert.AreEqual(0, responses[1].getVolume());
            Assert.AreEqual(15.35, responses[0].getShare().getPrice());
            Assert.AreEqual(-1, responses[1].getShare().getPrice());
            Assert.AreEqual("VIC", responses[0].getShare().getCode());
        }
    }
}
