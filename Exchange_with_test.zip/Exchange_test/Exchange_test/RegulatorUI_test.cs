﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;

//Except for the TestAddSharesAndGetAllShares(), the database is resetted after each test operation is performed.
namespace Exchange
{
    [TestClass]
    public class RegulatorUI_test
    {
        
        [TestMethod]
        public void TestGetInventoryReport()
        {
            BankManager bankM = new BankManager();
            ShareManager shareM = new ShareManager();
            RecordManager recordM = new RecordManager();
            RegulatorUI reUI = new RegulatorUI(bankM, shareM, recordM);
            //Sample shares: false means SOLD
            shareM.AddShare(new Share("FLC", 13.45, false), "RegulatorUI_SharesUnitTest.txt");
            shareM.AddShare(new Share("FLC", 13.45, false), "RegulatorUI_SharesUnitTest.txt");
            shareM.AddShare(new Share("VIC", 14.45), "RegulatorUI_SharesUnitTest.txt");
            shareM.AddShare(new Share("VIC", 14.45, false), "RegulatorUI_SharesUnitTest.txt");
            shareM.AddShare(new Share("VIC", 15.00), "RegulatorUI_SharesUnitTest.txt");
            Dictionary<System.Tuple<string, double>, System.Tuple<int, int>> share_dict =
                reUI.GetInventoryReport();
            //Assert
            Assert.AreEqual(3, share_dict.Count);
            Assert.AreEqual(new System.Tuple<int, int>(2, 2), share_dict[new System.Tuple<string, double>("FLC", 13.45)]);
            Assert.AreEqual(new System.Tuple<int, int>(2, 1), share_dict[new System.Tuple<string, double>("VIC", 14.45)]);
            Assert.AreEqual(new System.Tuple<int, int>(1, 0), share_dict[new System.Tuple<string, double>("VIC", 15.00)]);
        }

        [TestMethod]
        public void TestGetFinancialReport()
        {
            //Similar to bankM.GetAllBanks()
            BankManager bankM1 = new BankManager();
            ShareManager shareM1 = new ShareManager();
            RecordManager recordM1 = new RecordManager();
            RegulatorUI reUI1 = new RegulatorUI(bankM1, shareM1, recordM1);
            //Sample banks:
            bankM1.AddBank("A", "RegulatorUI_BanksUnitTest.txt");
            bankM1.AddBank("B", "RegulatorUI_BanksUnitTest.txt");
            Dictionary<int, Bank> bank_dict = reUI1.GetFinancialReport();
            //Reset bankID
            bankM1.resetIDtoAssign();
            //Assert
            Assert.AreEqual(2, bank_dict.Count);
            Assert.AreEqual(0, bank_dict[0].getMoneyOwed());
        }

        [TestMethod]
        public void TestGetTransactionLog()
        {
            //Similar to recordM.GetTransactionLog()
            BankManager bankM2 = new BankManager();
            ShareManager shareM2 = new ShareManager();
            RecordManager recordM2 = new RecordManager();
            RegulatorUI reUI2 = new RegulatorUI(bankM2, shareM2, recordM2);
            //Sample records:
            Bank bank = new Bank(0, "A");
            Share share = new Share("VIC", 14.45);
            //0
            recordM2.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RegulatorUI_RecordsUnitTest.txt");
            //1
            recordM2.CreateResponse(System.DateTime.Now, share, 1,
                            "quote", "RegulatorUI_RecordsUnitTest.txt");
            //2
            recordM2.CreateResponse(System.DateTime.Now, share, 1,
                            "only", "RegulatorUI_RecordsUnitTest.txt");
            //3
            recordM2.CreateResponse(System.DateTime.Now, share, 1,
                            "bought", "RegulatorUI_RecordsUnitTest.txt");
            //4
            recordM2.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RegulatorUI_RecordsUnitTest.txt");
            List<Request> requests = reUI2.GetTransactionLog();
            //Reset DB
            recordM2.resetRecordID();
            File.WriteAllText("RegulatorUI_RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(2, requests.Count);
            Assert.AreEqual(4, requests[1].getId());
        }

        [TestMethod]
        public void TestGetBankInvoice()
        {
            //Similar to recordM.GetGetBankSuccessfulTransactions(bankID)
            BankManager bankM3 = new BankManager();
            ShareManager shareM3 = new ShareManager();
            RecordManager recordM3 = new RecordManager();
            RegulatorUI reUI3 = new RegulatorUI(bankM3, shareM3, recordM3);
            //Sample records:
            Bank bank = new Bank(0, "A");
            Bank bank1 = new Bank(1, "B");
            Share share = new Share("VIC", 14.45);
            Share share1 = new Share("FLC", 13.55);
            //0
            recordM3.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RegulatorUI_RecordsUnitTest.txt");
            //1
            recordM3.CreateResponse(System.DateTime.Now, share, 1,
                            "bought", "RegulatorUI_RecordsUnitTest.txt");
            recordM3.SetResponseToARequest(0, 1);
            //2
            recordM3.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RegulatorUI_RecordsUnitTest.txt");
            //3
            recordM3.CreateResponse(System.DateTime.Now, share, 1,
                            "only", "RegulatorUI_RecordsUnitTest.txt");
            //4
            recordM3.CreateResponse(System.DateTime.Now, share, 1,
                            "quote", "RegulatorUI_RecordsUnitTest.txt");
            recordM3.SetResponseToARequest(2, 3);
            recordM3.SetResponseToARequest(2, 4);
            //5: bank 1
            recordM3.CreateRequest(System.DateTime.Now, share1, 1,
                                   bank1, "RegulatorUI_RecordsUnitTest.txt");
            //6: bank 1
            recordM3.CreateResponse(System.DateTime.Now, share1, 1,
                            "bought", "RegulatorUI_RecordsUnitTest.txt");
            recordM3.SetResponseToARequest(5, 6);
            //7
            recordM3.CreateRequest(System.DateTime.Now, share1, 10,
                                   bank, "RegulatorUI_RecordsUnitTest.txt");
            //8
            recordM3.CreateResponse(System.DateTime.Now, share1, 10,
                            "bought", "RegulatorUI_RecordsUnitTest.txt");
            recordM3.SetResponseToARequest(7, 8);
            List<Response> responses = reUI3.GetBankInvoice(0);
            List<Response> responses1 = reUI3.GetBankInvoice(1);
            //Assert
            Assert.AreEqual(2, responses.Count);
            Assert.AreEqual(8, responses[1].getId());
            Assert.AreEqual(1, responses1.Count);
            Assert.AreEqual(6, responses1[0].getId());
            Assert.AreEqual("FLC", responses1[0].getShare().getCode());
        }
    }
}
