﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;

//Except for the TestCreateRequest() and TestCreateResponse(), the database and recordID is resetted after each test operation is performed.
namespace Exchange
{
    [TestClass]
    public class RecordM_test
    {
        Bank bank = new Bank(0, "A");
        Bank bank1 = new Bank(1, "B");
        Share share = new Share("VIC", 14.45);
        Share share1 = new Share("FLC", 13.55);

        [TestMethod]
        public void TestCreateRequest()
        {
            //To test whether the request is created and added to the database successfully
            RecordManager recordM = new RecordManager();
            int requestID = recordM.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RecordsUnitTest_0.txt");
            //Assert
            Assert.AreEqual(0, requestID);
        }

        [TestMethod]
        public void TestCreateResponse()
        {
            //To test whether the request is created and added to the database successfully
            RecordManager recordM1 = new RecordManager();
            int responseID = recordM1.CreateResponse(System.DateTime.Now, share, 1,
                            "quote", "RecordsUnitTest_0.txt");
            recordM1.CreateResponse(System.DateTime.Now, share, 1,
                            "only", "RecordsUnitTest_0.txt");
            int responseID_1 = recordM1.CreateResponse(System.DateTime.Now, share, 1,
                            "bought", "RecordsUnitTest_0.txt");
            //Reset ID
            recordM1.resetRecordID();
            //Assert
            Assert.AreEqual(1, responseID);
            Assert.AreEqual(3, responseID_1);
        }

        [TestMethod]
        public void TestGetResponse()
        {
            //To test whether the response with matching ID is found
            RecordManager recordM2 = new RecordManager();
            recordM2.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RecordsUnitTest.txt");
            recordM2.CreateResponse(System.DateTime.Now, share, 1,
                            "quote", "RecordsUnitTest.txt");
            recordM2.CreateResponse(System.DateTime.Now, share, 1,
                            "only", "RecordsUnitTest.txt");
            recordM2.CreateResponse(System.DateTime.Now, share, 1,
                            "bought", "RecordsUnitTest.txt");
            Response response = recordM2.GetResponse(1);
            //Assert exception
            Assert.ThrowsException<KeyNotFoundException>(() =>
            {
                Response response1 = recordM2.GetResponse(10);
            });
            Assert.ThrowsException<System.InvalidCastException>(() =>
            {
                Response response1 = recordM2.GetResponse(0);
            });
            //Reset ID and database
            recordM2.resetRecordID();
            File.WriteAllText("RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual("quote", response.typeOfResponse);
        }

        [TestMethod]
        public void TestGetAllRequest()
        {
            //To test whether all requests are found
            RecordManager recordM3 = new RecordManager();
            //0
            recordM3.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RecordsUnitTest.txt");
            //1
            recordM3.CreateResponse(System.DateTime.Now, share, 1,
                            "quote", "RecordsUnitTest.txt");
            //2
            recordM3.CreateResponse(System.DateTime.Now, share, 1,
                            "only", "RecordsUnitTest.txt");
            //3
            recordM3.CreateResponse(System.DateTime.Now, share, 1,
                            "bought", "RecordsUnitTest.txt");
            //4
            recordM3.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RecordsUnitTest.txt");
            List<Request> requests = recordM3.GetAllRequest();
            //Reset ID and database
            recordM3.resetRecordID();
            File.WriteAllText("RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(2, requests.Count);
            Assert.AreEqual(4, requests[1].getId());
        }

        [TestMethod]
        public void TestSetResponseToARequest()
        {
            //To test whether the response is added to the request
            RecordManager recordM4 = new RecordManager();
            //Assert exception
            Assert.ThrowsException<KeyNotFoundException>(() =>
            {
                recordM4.SetResponseToARequest(0, 2);
            });
            recordM4.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RecordsUnitTest.txt");
            recordM4.CreateResponse(System.DateTime.Now, share, 1,
                            "only", "RecordsUnitTest.txt");
            recordM4.CreateResponse(System.DateTime.Now, share, 1,
                            "quote", "RecordsUnitTest.txt");
            recordM4.SetResponseToARequest(0, 1);
            recordM4.SetResponseToARequest(0, 2);
            //Assert exception
            Assert.ThrowsException<KeyNotFoundException>(() =>
            {
                recordM4.SetResponseToARequest(0, 10);
            });
            Assert.ThrowsException<System.InvalidCastException>(() =>
            {
                recordM4.SetResponseToARequest(0, 0);
            });
            Assert.ThrowsException<System.InvalidCastException>(() =>
            {
                recordM4.SetResponseToARequest(1, 0);
            });
            Request request = recordM4.GetAllRequest()[0];
            //Reset ID and database
            recordM4.resetRecordID();
            File.WriteAllText("RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual("only", request.getResponses()[0].typeOfResponse);
            Assert.AreEqual("quote", request.getResponses()[1].typeOfResponse);
        }

        [TestMethod]
        public void TestGetGetBankSuccessfulTransactions()
        {
            //To test whether all responses from a successful transactions
            // of a bank are found
            RecordManager recordM5 = new RecordManager();
            //0
            recordM5.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RecordsUnitTest.txt");
            //1
            recordM5.CreateResponse(System.DateTime.Now, share, 1,
                            "bought", "RecordsUnitTest.txt");
            recordM5.SetResponseToARequest(0, 1);
            //2
            recordM5.CreateRequest(System.DateTime.Now, share, 1,
                                   bank, "RecordsUnitTest.txt");
            //3
            recordM5.CreateResponse(System.DateTime.Now, share, 1,
                            "only", "RecordsUnitTest.txt");
            //4
            recordM5.CreateResponse(System.DateTime.Now, share, 1,
                            "quote", "RecordsUnitTest.txt");
            recordM5.SetResponseToARequest(2, 3);
            recordM5.SetResponseToARequest(2, 4);
            //5: bank 1
            recordM5.CreateRequest(System.DateTime.Now, share1, 1,
                                   bank1, "RecordsUnitTest.txt");
            //6: bank 1
            recordM5.CreateResponse(System.DateTime.Now, share1, 1,
                            "bought", "RecordsUnitTest.txt");
            recordM5.SetResponseToARequest(5, 6);
            //7
            recordM5.CreateRequest(System.DateTime.Now, share1, 10,
                                   bank, "RecordsUnitTest.txt");
            //8
            recordM5.CreateResponse(System.DateTime.Now, share1, 10,
                            "bought", "RecordsUnitTest.txt");
            recordM5.SetResponseToARequest(7, 8);
            List<Response> responses = recordM5.GetGetBankSuccessfulTransactions(0);
            List<Response> responses1 = recordM5.GetGetBankSuccessfulTransactions(1);
            //Reset ID and database
            recordM5.resetRecordID();
            File.WriteAllText("RecordsUnitTest.txt", "");
            //Assert
            Assert.AreEqual(2, responses.Count);
            Assert.AreEqual(1, responses[0].getId());
            Assert.AreEqual("FLC", responses[1].getShare().getCode());
            Assert.AreEqual(1, responses1.Count);
            Assert.AreEqual(6, responses1[0].getId());
        }

    }
}
