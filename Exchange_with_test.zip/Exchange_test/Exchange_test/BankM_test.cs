﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;

//Except for TestAddBank1(), the same database is used to store testing data. Therefore, the content will be deleted after each test operation is perforned.
//Because bankIDtoAssign is a static int; therefore, it will be set back to 0 after each test operation is perforned.
namespace Exchange
{
    [TestClass]
    public class BankM_test
    {
        [TestMethod]
        public void TestAddBank1()
        { 
            //Test if the bank is created and assigned an ID succesfully, and if the bank info is written correctly in the database
            BankManager bankM = new BankManager();
            int bankId = bankM.AddBank("A","BanksUnitTest_0.txt");
            //Reset ID and database
            bankM.resetIDtoAssign();
            File.WriteAllText("BanksUnitTest_0.txt", "");
            //Assert
            Assert.AreEqual(0, bankId);
        }


        [TestMethod]
        public void TestAddBank2()
        {
            //2 bank can have the same account name as long as they have different ID
            BankManager bankM1 = new BankManager();
            int bankId = bankM1.AddBank("A", "BanksUnitTest.txt");
            int bankId1 = bankM1.AddBank("A", "BanksUnitTest.txt");
            //Reset ID and database
            bankM1.resetIDtoAssign();
            File.WriteAllText("BanksUnitTest.txt", "");
            //Assert
            Assert.AreEqual(bankId, bankId1-1);
        }

        [TestMethod]
        public void TestFindBank()
        {
            BankManager bankM2 = new BankManager();
            bankM2.AddBank("A", "BanksUnitTest.txt");
            bankM2.AddBank("B", "BanksUnitTest.txt");
            bankM2.AddBank("C", "BanksUnitTest.txt");
            Bank found = bankM2.FindBank(2);
            //Assert exception
            Assert.ThrowsException<KeyNotFoundException>(() =>
            {
                Bank found1 = bankM2.FindBank(5);
            });
            //Reset ID and database
            bankM2.resetIDtoAssign();
            File.WriteAllText("BanksUnitTest.txt", "");
            //Assert
            Assert.AreEqual("C", found.getName());   
        }

        [TestMethod]
        public void TestGetAllBanks()
        {
            //To test whether the bank is added to the Dictionary 
            BankManager bankM3 = new BankManager();
            bankM3.AddBank("A", "BanksUnitTest.txt");
            bankM3.AddBank("B", "BanksUnitTest.txt");
            //Reset ID and database
            bankM3.resetIDtoAssign();
            File.WriteAllText("BanksUnitTest.txt", "");
            //Assert
            Assert.AreEqual(2, bankM3.GetAllBanks().Count);
        }

        [TestMethod]
        public void TestSetMoneyOwed()
        {
            BankManager bankM4 = new BankManager();
            bankM4.AddBank("A", "BanksUnitTest.txt");
            bankM4.SetMoneyOwed(0, 123.45);
            //Reset database
            bankM4.resetIDtoAssign();
            File.WriteAllText("BanksUnitTest.txt", "");
            //Assert
            Assert.AreEqual(123.45, bankM4.FindBank(0).getMoneyOwed());
        }


        [TestMethod]
        public void TestUpdateBankDB()
        {
            BankManager bankM6 = new BankManager();
            bankM6.AddBank("A", "BanksUnitTest.txt");
            bankM6.AddBank("B", "BanksUnitTest.txt");
            //Add some modification to the data
            bankM6.SetMoneyOwed(0, 13579.24);
            //Update the data
            bankM6.updateBankDB("BanksUnitTest.txt");
            string[] lines = File.ReadAllLines("BanksUnitTest.txt");
            string line_to_test = lines[0];
            //Reset ID and database
            bankM6.resetIDtoAssign();
            File.WriteAllText("BanksUnitTest.txt", "");
            //Assert
            Assert.AreEqual("{\"id\":0,\"name\":\"A\",\"moneyOwed\":13579.24}", line_to_test);
        }

    }
}
