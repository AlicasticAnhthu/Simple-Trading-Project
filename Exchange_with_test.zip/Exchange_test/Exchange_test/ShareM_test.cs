﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;

//Except for the TestAddSharesAndGetAllShares(), the database is resetted after each test operation is performed.
namespace Exchange
{
    [TestClass]
    public class ShareM_test
    {
        [TestMethod]
        public void TestAddSharesAndGetAllShares()
        {
            //To test if the new share is added to the List and written to the database
            ShareManager shareM = new ShareManager();
            shareM.AddShare(new Share("VIC", 14.45), "SharesUnitTest_0.txt");
            shareM.AddShare(new Share("VIC", 14.45), "SharesUnitTest_0.txt");
            //Assert
            Assert.AreEqual(2, shareM.GetAllShares().Count);
        }

        [TestMethod]
        public void TestFindShare()
        {
            ShareManager shareM1 = new ShareManager();
            shareM1.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM1.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM1.AddShare(new Share("VIC", 15.00), "SharesUnitTest.txt");
            shareM1.AddShare(new Share("VIC", 15.30), "SharesUnitTest.txt");
            shareM1.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM1.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM1.AddShare(new Share("VNM", 15.30), "SharesUnitTest.txt");
            shareM1.AddShare(new Share("VNM", 15.56), "SharesUnitTest.txt");
            List<Share> found_shares = shareM1.FindShare("VIC");
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual(4, found_shares.Count);
        }

        [TestMethod]
        public void TestGetQuotePrice1()
        {
            //Case 1: basePrice given < minimum price of the shares 
            ShareManager shareM2 = new ShareManager();
            shareM2.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM2.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM2.AddShare(new Share("VIC", 15.00), "SharesUnitTest.txt");
            shareM2.AddShare(new Share("VIC", 15.30), "SharesUnitTest.txt");
            shareM2.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM2.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM2.AddShare(new Share("VNM", 15.30), "SharesUnitTest.txt");
            shareM2.AddShare(new Share("VNM", 15.56), "SharesUnitTest.txt");
            double quoteprice = shareM2.GetQuotePrice(shareM2.GetAllShares(), 10);
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual(13.45, quoteprice);
        }

        [TestMethod]
        public void TestGetQuotePrice2()
        {
            //Case 2: minimum price of the shares < basePrice given < maximum price of the shares 
            ShareManager shareM3 = new ShareManager();
            shareM3.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM3.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM3.AddShare(new Share("VIC", 15.00), "SharesUnitTest.txt");
            shareM3.AddShare(new Share("VIC", 15.30), "SharesUnitTest.txt");
            shareM3.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM3.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM3.AddShare(new Share("VNM", 15.30), "SharesUnitTest.txt");
            shareM3.AddShare(new Share("VNM", 15.56), "SharesUnitTest.txt");
            double quoteprice = shareM3.GetQuotePrice(shareM3.GetAllShares(), 14.75);
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual(15.00, quoteprice);
        }

        [TestMethod]
        public void TestGetQuotePrice3()
        {
            //Case 3: basePrice given > maximum price of the shares 
            ShareManager shareM4 = new ShareManager();
            shareM4.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 15.00), "SharesUnitTest.txt");
            shareM4.AddShare(new Share("VIC", 15.30), "SharesUnitTest.txt");
            shareM4.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM4.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM4.AddShare(new Share("VNM", 15.30), "SharesUnitTest.txt");
            shareM4.AddShare(new Share("VNM", 15.56), "SharesUnitTest.txt");
            double quoteprice = shareM4.GetQuotePrice(shareM4.GetAllShares(), 15.57);
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual(-1, quoteprice);
        }

        [TestMethod]
        public void TestGetSharesToBuy()
        {
            //Test whether all shares with price lower or equal to the request price are found
            ShareManager shareM5 = new ShareManager();
            shareM5.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM5.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM5.AddShare(new Share("VIC", 15.00), "SharesUnitTest.txt");
            shareM5.AddShare(new Share("VIC", 15.30), "SharesUnitTest.txt");
            shareM5.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM5.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM5.AddShare(new Share("VNM", 15.30), "SharesUnitTest.txt");
            shareM5.AddShare(new Share("VNM", 15.56), "SharesUnitTest.txt");
            List<Share> found_shares = shareM5.GetSharesToBuy(shareM5.GetAllShares(), 15.00);
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual(5, found_shares.Count);
        }

        [TestMethod]
        public void TestGetSharesAtAPrice()
        {
            //Test whether all shares at the request price are found
            ShareManager shareM6 = new ShareManager();
            shareM6.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM6.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM6.AddShare(new Share("VIC", 15.00), "SharesUnitTest.txt");
            shareM6.AddShare(new Share("VIC", 15.30), "SharesUnitTest.txt");
            shareM6.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM6.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM6.AddShare(new Share("VNM", 15.30), "SharesUnitTest.txt");
            shareM6.AddShare(new Share("VNM", 15.56), "SharesUnitTest.txt");
            List<Share> found_shares = shareM6.GetSharesAtAPrice(shareM6.GetAllShares(), 14.45);
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual(2, found_shares.Count);
        }

        [TestMethod]
        public void TestGetAvailableShares()
        {
            //Test whether all shares at the request price are found
            ShareManager shareM7 = new ShareManager();
            shareM7.AddShare(new Share("VIC", 14.45, false), "SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 14.45, false), "SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 15.00, false), "SharesUnitTest.txt");
            shareM7.AddShare(new Share("VIC", 15.30, false), "SharesUnitTest.txt");
            shareM7.AddShare(new Share("FLC", 13.45, false), "SharesUnitTest.txt");
            shareM7.AddShare(new Share("FLC", 13.45), "SharesUnitTest.txt");
            shareM7.AddShare(new Share("VNM", 15.30), "SharesUnitTest.txt");
            shareM7.AddShare(new Share("VNM", 15.56), "SharesUnitTest.txt");
            List<Share> found_shares = shareM7.GetAvailableShares(shareM7.GetAllShares());
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual(3, found_shares.Count);
        }

        [TestMethod]
        public void TestUpdateShareDB()
        {
            ShareManager shareM9 = new ShareManager();
            shareM9.AddShare(new Share("VIC", 14.45), "SharesUnitTest.txt");
            shareM9.AddShare(new Share("VIC", 15.55, false), "SharesUnitTest.txt");
            //Add modification to the data
            shareM9.GetAllShares()[0].setState(false);
            shareM9.GetAllShares()[1].setState(true);
            //Update the data
            shareM9.updateShareDB("SharesUnitTest.txt");
            string[] lines = File.ReadAllLines("SharesUnitTest.txt");
            //Reset Database
            File.WriteAllText("SharesUnitTest.txt", "");
            //Assert
            Assert.AreEqual("{\"code\":\"VIC\",\"price\":14.45,\"state\":false}", lines[0]);
            Assert.AreEqual("{\"code\":\"VIC\",\"price\":15.55,\"state\":true}", lines[1]);
        }
    }
}
